/*
 * This model of scale assumes use of the chromatic scale, i.e. 12 notes per octave.
 */
#ifndef Scale_h
#define Scale_h
#include "Arduino.h"

class Scale {
    
  public:
  
    char* scaleName;
    uint8_t* scaleNotes;  
    uint8_t scaleLength;
    
    Scale();
    void setScale(const char* NAME, const uint8_t* NOTES, uint8_t LENGTH);
    int getNote(int INDEX);

};

#endif
