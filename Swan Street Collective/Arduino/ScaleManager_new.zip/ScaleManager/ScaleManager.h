#ifndef ScaleManager_h
#define ScaleManager_h
#include "Arduino.h"
#include "Scale.h"
#include "noteDefs.h"

#define CHROMATIC 0
#define MAJOR 1
#define MINOR 2
#define PENTATONIC 3

#define MAX_SCALES 16

class ScaleManager {
  public:  //currently, all variables are public
    const char* noteNames[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    byte currentScale = 0;
    byte fundamental = 60; //middle C is default
    Scale scales[MAX_SCALES];
    byte scalesLoaded = 0;
  
    ScaleManager();
    ScaleManager(boolean DEFAULTS);
    int getScaleNote(int NOTE);
    float getScaleNoteFrequency(int NOTE);
    float getFrequency(int NOTE);
    char* getNoteName(int NOTE);
    char* getScaleNoteName(int NOTE);
    byte getNoteOctave(int NOTE);
    byte getScaleNoteOctave(int NOTE);
    char* getFundamentalName();
    byte getFundamentalOctave();
    char* getScaleName();
    byte getNumScales();

    void setFundamental(byte F);
    void setCurrentScale(byte S);
    byte addScale(const char* NAME, const byte* NOTES, byte LENGTH);
};

#endif
