#include "Arduino.h"
#include "ScaleManager.h"

ScaleManager::ScaleManager() {
}

ScaleManager::ScaleManager(boolean DEFAULTS) {
  if (DEFAULTS) {
    addScale("Chromatic",  (const byte[]) {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}, 12);
    addScale("Major",      (const byte[]) {0, 2, 4, 5, 7, 9, 11 },                7 );
    addScale("Minor",      (const byte[]) {0, 2, 3, 5, 7, 8, 10 },                7 );
    addScale("Pentatonic", (const byte[]) {0, 2, 4, 7, 9 },                       5 );
  }
}

int ScaleManager::getScaleNote(int NOTE) {
  return fundamental + scales[currentScale].getNote(NOTE);
}

float ScaleManager::getScaleNoteFrequency(int NOTE) {
  return getFrequency(getScaleNote(NOTE));
}

float ScaleManager::getFrequency(int NOTE) {
  return 220*pow(2,(float(NOTE-57))/12);
}

char* ScaleManager::getNoteName(int NOTE){
  return (char*) noteNames[NOTE%12];
}

char* ScaleManager::getScaleNoteName(int NOTE){
  return getNoteName(getScaleNote(NOTE));
}

byte ScaleManager::getNoteOctave(int NOTE){
  return NOTE/12;
}

byte ScaleManager::getScaleNoteOctave(int NOTE){
  return getNoteOctave(getScaleNote(NOTE));
}

char* ScaleManager::getFundamentalName() {
  return getNoteName(fundamental);
}

byte ScaleManager::getFundamentalOctave(){
  return getNoteOctave(fundamental);
}

char* ScaleManager::getScaleName() {
  return scales[currentScale].scaleName;
}

byte ScaleManager::getNumScales(){
  return scalesLoaded;
}

void ScaleManager::setFundamental(byte F) {
  fundamental = F;
}

void ScaleManager::setCurrentScale(byte S) {
  currentScale = S;
}

byte ScaleManager::addScale(const char* NAME, const byte* NOTES, const byte LENGTH) {
  if (scalesLoaded < MAX_SCALES) {
    scales[scalesLoaded].setScale(NAME, NOTES, LENGTH);
    scalesLoaded++;
    return scalesLoaded;
  }else{
    return 0;
  }
}
